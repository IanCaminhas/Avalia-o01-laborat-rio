<?php $__env->startSection('conteudo'); ?>


        <?php if(isset($response)): ?>
            <?php echo e($response); ?>

        <?php endif; ?>


    <form action="/bolsa/index">
        <div>
            <button class="btn btn-primary" type="submit">retornar</button>
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ianca\OneDrive\Área de Trabalho\bolsavalores\resources\views/resultado_transacao.blade.php ENDPATH**/ ?>