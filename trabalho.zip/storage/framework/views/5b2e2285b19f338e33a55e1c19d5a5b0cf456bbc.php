<?php $__env->startSection('conteudo'); ?>

    <table class="table table-striped col-lg-12">
        <thead>
        <tr>
            <th scope="col">Broker</th>
            <th scope="col">Natureza</th>
            <th scope="col">Ativo</th>
            <th scope="col">Quantidade lotes</th>
        </thead>
        <tbody>

        </tr>
        <?php if(isset($ordens)): ?>
          <?php $__currentLoopData = $ordens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($o->broker->nome); ?></td>
                    <td><?php echo e($o->natureza); ?></td>
                    <td><?php echo e($o->ativo->nome_pregao); ?></td>
                    <td><?php echo e($o->qtd_lotes); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </tbody>
    </table>


    <form action="/bolsa/form_ordens" method="post" id="ordem_compra">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>

        <div class="form-group">
            <label>Nome Broker:</label>
            <input name="broker" class="form-control" />
        </div>

        <div class="form-group">
            <label>Senha:</label>
            <input name="senha" type="password" class="form-control" />
        </div>

        <div>
            <button class="btn btn-primary" type="submit">pesquisar</button>
        </div>
    </form>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ianca\OneDrive\Área de Trabalho\bolsavalores\resources\views/form_ordens.blade.php ENDPATH**/ ?>