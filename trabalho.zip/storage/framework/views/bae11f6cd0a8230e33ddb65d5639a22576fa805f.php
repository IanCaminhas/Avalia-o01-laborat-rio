<?php $__env->startSection('conteudo'); ?>


    <div class="alert-danger">

     <?php if(isset($response)): ?>
            <div class="alert alert-danger">
                <?php echo e($response); ?>

            </div>
                <?php endif; ?>
    </div>


    <form action="/bolsa/add_broker" method="post" id="ordem_compra">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>

        <div class="form-group">
            <label>Nome Broker:</label>
            <input name="nome" class="form-control" />
        </div>

        <div class="form-group">
            <label>Senha:</label>
            <input name="senha" type="password" class="form-control" />
        </div>

        <div>
            <button class="btn btn-primary" type="submit">cadastrar</button>
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ianca\OneDrive\Área de Trabalho\bolsavalores\resources\views/form_add_broker.blade.php ENDPATH**/ ?>