<!doctype html>

<html>
<head>
    <link rel="stylesheet" type="text/css" href="/css/app.css">
    <title>Login</title>
</head>
<body>
<form action="/bolsa/login" method="post">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>

    <div class="form-group">
        <label>Email</label>
        <input name="email" class="form-control" />
    </div>

    <div class="form-group">
        <label>Senha</label>
        <input name="password" type="password" class="form-control" />
    </div>

    <button class="btn btn-primary" type="submit">Login</button>

</body>


</html><?php /**PATH C:\Users\ianca\OneDrive\Área de Trabalho\bolsavalores\resources\views/form_login.blade.php ENDPATH**/ ?>