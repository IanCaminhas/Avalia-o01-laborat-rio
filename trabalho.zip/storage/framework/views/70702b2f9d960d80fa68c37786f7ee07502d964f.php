<?php $__env->startSection('conteudo'); ?>

<div class="container">
    <!--
<table class="table table-striped col-lg-12">
    <thead>
    <tr>
        <th scope="col">Broker</th>
        <th scope="col">Natureza</th>
        <th scope="col">Lotes</th>
        <th scope="col">Valor</th>
        <th scope="col">Comprar</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>

-->

<form action="/bolsa/add_ordem" method="post" id="ordem_compra">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>

    <div class="form-group">
        <label>Numero de lotes:</label>
        <input name="lotes" class="form-control" />
    </div>

    <div>
        <label>Natureza da ordem:</label>
        <select name="natureza" class="form-control" />
            <option value="compra">compra</option>
            <option value="venda">venda</option>
        </select>
    </div>


    <div>
        <label>Ativo:</label>
        <select name="codigo_ativo" class="form-control" />
        <?php $__currentLoopData = $ativos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($a->codigo); ?>"><?php echo e($a->nome_pregao); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
    </div>

    <div class="form-group">
        <label>A sua identificação como broker: </label>
        <input name="broker" class="form-control" />
    </div>

    <div class="form-group">
        <label>Senha:</label>
        <input name="senha" class="form-control" type="password" />
    </div>

    <div>
    <button class="btn btn-primary" type="submit">emitir</button>
    </div>

</form>
</div>

    <div class="alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

<!--
<div class="alert-danger">

    <?php if(isset($response)): ?>
        <div class="alert alert-danger">
            <?php echo e($response); ?>

        </div>
    <?php endif; ?>
</div>
-->





<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ianca\OneDrive\Área de Trabalho\bolsavalores\resources\views/bolsa_form.blade.php ENDPATH**/ ?>