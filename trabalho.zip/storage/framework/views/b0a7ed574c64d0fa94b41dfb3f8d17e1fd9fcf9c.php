<?php $__env->startSection('conteudo'); ?>
    <h1>Ativos da bolsa de valores</h1>
    <table class="table table-striped col-lg-12">
        <thead>
        <tr>
            <th scope="col">Nome Pregão</th>
            <th scope="col">Código</th>
            <th scope="col">Atividade Principal</th>
        </tr>
        <?php $__currentLoopData = $ativos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ativo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($ativo->codigo); ?></td>
            <td><?php echo e($ativo->nome_pregao); ?></td>
            <td><?php echo e($ativo->atividade_principal); ?></td>
        </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </thead>
        <tbody>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ianca\OneDrive\Área de Trabalho\bolsavalores\resources\views/form_ativos.blade.php ENDPATH**/ ?>