<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Broker extends Model
{
    protected $table = "broker";
    protected $fillable=array('nome','senha');


    public function ativo(){
        return $this->hasMany('App\Ativo');
    }

    public function ordem(){
        return $this->hasMany('App\Ativo');
    }




}



