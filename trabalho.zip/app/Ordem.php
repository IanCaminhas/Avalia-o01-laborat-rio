<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ordem extends Model
{
    protected $table='ordem';
    protected $fillable= array('lotes','natureza','codigo_ativo','codigo_broker');

   public function broker(){
       return $this->belongsTo('App\Broker');
   }

    public function ativo(){
        return $this->belongsTo('App\Ativo');
    }



}

