<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ativo extends Model
{
    protected $table="ativo";
    protected $fillable= array('codigo','nome_pregao','atividade_principal','qtd_lotes','valor_lote');

    public function broker(){
        return $this->hasMany('App\Broker');
    }

    public function ordem(){
        return $this->hasMany('App\Ordem');
    }

}
