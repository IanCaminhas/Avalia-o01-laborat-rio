<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class OrdemRequest extends FormRequest
{

    public function authorize()
    {
        return true;
    }


    public function rules()
    {
        return [
            'lotes'=>'required|numeric',
            'natureza'=>'required',
            'broker'=>'required',
            'senha'=>'required',
            'codigo_ativo'=>'required',

        ];
    }

    public function messages()
    {
        return [
            'lotes.required'=>'A quantidade de :attribute é obrigatória!',
            'natureza.required'=>'A natureza da operação é obrigatória!',
            'broker.required'=>'A identificação do :attribute é obrigatória!',
            'senha.required'=>'A senha de identificação é obrigatória!',
            'codigo_ativo.required'=>'É necessário selecionar o ativo!',
            'lotes.numeric' =>'A quantidade de lotes deve ser numérico'

        ];
    }



}
