<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class BrokerRequest extends FormRequest
{

    public function authorize()
    {
        return true;
    }


    public function rules()
    {
        return [
            'nome' =>'required',
            'senha' =>'required',
        ];
    }

    public function messages()
    {
        return [
          'name.required' =>'O atributo nome e obrigatorio',
            'senha.required' => 'o atributo senha é obrigatório',

        ];
    }


}
