<?php

namespace App\Http\Controllers;

use App\Ativo;
use App\Broker;
use App\Http\Requests\BrokerRequest;
use App\Http\Requests\OrdemRequest;
use App\Ordem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;


class BolsaController extends Controller
{

    public function index(){
        return view('bolsa_form')->with('ativos', Ativo::all());
    }

    public function formAddBroker(){
        return view('form_add_broker');
    }

    public function ativos(){
        return view('form_ativos')->with('ativos',Ativo::all());
    }

    public function addBroker(BrokerRequest $request){
        $senha = md5($request->input('senha'));
        $nomeBroker =$request->input('nome');

        //verificar s existe usuário
        $broker = DB::select('select *from broker WHERE nome=(?)', array($nomeBroker));
        if($broker!=null){
            return view('form_add_broker')->with('response', "Usuário já existente");
        }

        DB::insert('insert into broker (nome,senha) values(?,?)', array($nomeBroker,$senha));
        return redirect('/bolsa/index');
    }

    public function addOrdem(OrdemRequest $request){
        $ativos=Ativo::all();
        $idBroker=$this->getIdBroker($request);
        if($idBroker>0){

            $natureza = $request->input('natureza');
            if($natureza=="compra"){
                $responseOrdemCompra = $this->processarOrdemCompra($request,$idBroker);
                return view('resultado_transacao')->with('response',$responseOrdemCompra);


            }else{
                $responseOrdemVenda= $this->processarOrdemVenda($request,$idBroker);
                return view('resultado_transacao')->with('response',$responseOrdemVenda);
            }
        }

        if($idBroker==-1){
            return view('resultado_transacao')->with('response',"Você não está cadastrado para realizar transação");
          }

        return view('resultado_transacao')->with('response',"Senha incorreta!" );

    }

    private function processarOrdemCompra(Request $request, $id){

        //verificar se tem lotes disponíveis
        $lotes = $request->input('lotes');
        $codigo_ativo= $request->input('codigo_ativo');

        $ativo = DB::select('select * from ativo WHERE codigo=(?)', array($codigo_ativo));


        if($lotes>$ativo[0]->qtd_lotes){
            return "Lotes de ações é superior à existente para o ativo";
        }

        DB::insert('insert into ordem (lotes,natureza,codigo_ativo,codigo_broker) values (?,?,?,?)',array($lotes,"compra",$codigo_ativo,$id));
        DB::update('update ativo set qtd_lotes=qtd_lotes - (?) WHERE codigo=(?)', array($lotes,$codigo_ativo));
        $cardeneta= DB::select('select * from cardeneta WHERE broker_id=(?) and codigo_ativo=(?)', array($id,$codigo_ativo));

        if($cardeneta==null){
            DB::insert('insert into cardeneta (broker_id,codigo_ativo,qtd_lotes) values (?,?,?)', array($id,$codigo_ativo,0));
        }

        DB::update('update cardeneta set qtd_lotes=qtd_lotes + (?) WHERE broker_id = (?) and codigo_ativo=(?) ', array($lotes,$id,$codigo_ativo));

        return "Ordem de compra realizada com sucesso";
    }

    private function processarOrdemVenda(Request $request, $id){

        $codigo_ativo= $request->input('codigo_ativo');
        $cardeneta= DB::select('select * from cardeneta WHERE broker_id=(?) and codigo_ativo=(?)', array($id,$codigo_ativo));
        $lotes = $request->input('lotes');

        if($cardeneta==null || $cardeneta[0]->qtd_lotes<$lotes){
            return "Você não tem recursos suficientes para realizar a ordem de venda";
        }

        DB::update('update cardeneta set qtd_lotes=qtd_lotes - (?) WHERE broker_id = (?) and codigo_ativo=(?) ', array($lotes,$id,$codigo_ativo));
        DB::update('update ativo set qtd_lotes=qtd_lotes + (?) WHERE codigo=(?)', array($lotes,$codigo_ativo));

        return "Ordem efetivada com sucesso";
    }

    private function getIdBroker(Request $request){
        $nomeBroker = $request->input('broker');
        $senhaBroker = md5($request->input('senha'));

        $credencialBroker = DB::select('select * from broker where nome=(?)', array($nomeBroker));

        if($credencialBroker==null){
            return -1;
        }

        if($credencialBroker[0]->senha==$senhaBroker){
            return $credencialBroker[0]->id;
        }

        return 0;
    }

    public function ordens(){
        return view('form_ordens');
    }

    public function ordensBroker(Request $request){
        $nomeBroker = $request->input('broker');
        $broker = DB::select('select * from broker WHERE nome=(?)',array($nomeBroker));
        $ordensBroker = DB::select('select * from ordem WHERE codigo_broker=(?)', array($broker[0]->id));
        return view('form_ordens')->with('ordens',$ordensBroker);
    }






}
