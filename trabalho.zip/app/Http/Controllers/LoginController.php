<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class LoginController extends Controller
{
    public function form(){
        return view('form_login');
    }

    public function login(Request $request){
        $credenciais = $request->only('email','password');
        //  attempt - verifica credenciais e loga
        //validate - apenas verifica crendeciais
        if(Auth::attempt($credenciais)){
            return redirect('bolsa/index');
        }

        return redirect('bolsa');
    }
}
