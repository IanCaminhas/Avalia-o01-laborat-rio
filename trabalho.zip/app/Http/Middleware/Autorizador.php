<?php

namespace App\Http\Middleware;
use Illuminate\Support\Facades\Auth;


use Closure;

class Autorizador
{

    public function handle($request, Closure $next)
    {
        /*
        if(!$request->is('bolsa') && Auth::guest()){
            return route('/bolsa/login');
        }
        */
        return $next($request);

    }
}
