<?php

use Illuminate\Database\Seeder;

class AtivoTableSeeder extends Seeder
{

    public function run()
    {
        DB::table('ativo')->insert([
            'codigo'=> 'ABEV3',
            'nome_pregao' => 'AMBEV S/A ON',
            'atividade_principal' =>'Fabricação e Distribuição de Cervejas. Refrigerantes e Bebidas
            Não Carbonatadas e Não Alcoólicas',
            'qtd_lotes' =>100,
            'valor_lote'=>100,
        ]);

        DB::table('ativo')->insert([
            'codigo'=> 'PETR4',
            'nome_pregao' => 'PETROBRAS PN',
            'atividade_principal' =>'Petróleo. Gás e Energia',
            'qtd_lotes' =>100,
            'valor_lote'=>200,

        ]);

        DB::table('ativo')->insert([
            'codigo'=> 'VALE5',
            'nome_pregao' => 'VALE PNA',
            'atividade_principal' =>'Mineração',
            'qtd_lotes' =>100,
            'valor_lote'=>50,

        ]);


        DB::table('ativo')->insert([
            'codigo'=> 'ITUB4',
            'nome_pregao' => 'ITAUUNIBANCO PN',
            'atividade_principal' =>'A Sociedade Tem por Objeto A Atividade Bancária',
            'qtd_lotes' =>100,
            'valor_lote'=>250,

        ]);


        DB::table('ativo')->insert([
            'codigo'=> 'BBDC4',
            'nome_pregao' => 'BRADESCO PN',
            'atividade_principal' =>'Prática de Operações Bancárias em Geral. Inclusive Câmbio',
            'qtd_lotes' =>100,
            'valor_lote'=>10,
        ]);

        DB::table('ativo')->insert([
        'codigo'=> 'BBAS3',
        'nome_pregao' => 'BRASIL ON',
        'atividade_principal' =>' Banco Múltiplo',
            'qtd_lotes' =>100,
            'valor_lote'=>230,
      ]);

        DB::table('ativo')->insert([
            'codigo'=> 'CIEL3',
            'nome_pregao' => 'CIELO ON',
            'atividade_principal' =>'Empresa Prestadora de Serviços de Adquirência e Meios de Pagamento',
            'qtd_lotes' =>100,
            'valor_lote'=>15,
        ]);

        DB::table('ativo')->insert([
            'codigo'=> 'PETR3',
            'nome_pregao' => 'PETROBRAS ON',
            'atividade_principal' =>' Petróleo. Gás e Energia',
            'qtd_lotes' =>100,
            'valor_lote'=>200,
        ]);

        DB::table('ativo')->insert([
            'codigo'=> 'HYPE3',
            'nome_pregao' => 'HYPERMARCAS ON',
            'atividade_principal' =>'Produção e Venda de Bens de Consumo e Medicamentos',
            'qtd_lotes' =>100,
            'valor_lote'=>10,
        ]);

        DB::table('ativo')->insert([
            'codigo'=> 'VALE3',
            'nome_pregao' => 'VALE ON',
            'atividade_principal' =>'Mineração',
            'qtd_lotes' =>100,
            'valor_lote'=>5,
        ]);

        DB::table('ativo')->insert([
            'codigo'=> 'BBSE3',
            'nome_pregao' => 'BBSEGURIDADE ON',
            'atividade_principal' =>' Participação no Capital Social de Outras Sociedades. que Tenham
             por Atividade Operações de Seguros. Resseguros. Previdências
             Complementar ou Capitalização',
            'qtd_lotes' =>120,
            'valor_lote'=>20,
        ]);

        DB::table('ativo')->insert([
            'codigo'=> 'CTIP3',
            'nome_pregao' => 'CETIP ON',
            'atividade_principal' =>' Sociedade Administradora de Mercados de Balcão Organizados',
            'qtd_lotes' =>140,
            'valor_lote'=>100,
        ]);


        DB::table('ativo')->insert([
            'codigo'=> 'GGBR4',
            'nome_pregao' => 'GERDAU PN',
            'atividade_principal' =>'Participação e Administração',
            'qtd_lotes' =>100,
            'valor_lote'=>100,
        ]);

        DB::table('ativo')->insert([
            'codigo'=> 'FIBR3',
            'nome_pregao' => 'FIBRIA ON',
            'atividade_principal' =>'Participação e Administração',
            'valor_lote'=>100,
            'qtd_lotes' =>100,

        ]);

        DB::table('ativo')->insert([
            'codigo'=> 'RADL3',
            'nome_pregao' => 'RAIADROGASIL ON',
            'atividade_principal' =>' Comércio de Produtos Farmacêuticos. Perfumarias e Afins',
            'qtd_lotes' =>100,
            'valor_lotes' =>100,

        ]);












    }
}
