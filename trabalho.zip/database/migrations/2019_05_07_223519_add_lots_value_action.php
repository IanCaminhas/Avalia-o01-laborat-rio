<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddLotsValueAction extends Migration
{

    public function up()
    {
        Schema::table('ativo', function ($table){
            $table->integer('qtd_lotes');
            $table->float('valor_lote');
        });
    }


    public function down()
    {
        Schema::table('ativo', function ($table){
            $table->dropColumn('qtd_lotes');
            $table->dropColumn('valor_lote');

        });
    }

}
