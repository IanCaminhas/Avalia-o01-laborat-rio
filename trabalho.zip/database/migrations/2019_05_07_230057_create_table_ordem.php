<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableOrdem extends Migration
{

    public function up()
    {

        //lotes','natureza','codigo_ativo','codigo_broker'
        Schema::create('ordem', function (Blueprint $table) {
            $table->increments('id')->unsigned();
            $table->integer('lotes');
            $table->string('natureza');
            $table->string('codigo_ativo',100);
            $table->integer('codigo_broker');

            $table->foreign('codigo_ativo')->references('codigo')->on('ativo')->onDelete('cascade');
            //$table->foreign('codigo_broker')->references('id')->on('broker')->onDelete('cascade');

            $table->timestamps();
        });

    }


    public function down()
    {

        Schema::dropIfExists('ordem');

    }
}
