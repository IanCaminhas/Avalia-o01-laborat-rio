<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/bolsa/index', "BolsaController@index");
Route::get('/bolsa', "LoginController@form");
Route::get('/bolsa/form_add',"BolsaController@formAddBroker");
Route::get('/bolsa/ativos', 'BolsaController@ativos');
Route::get('/bolsa/form_ordens', 'BolsaController@ordens');
Route::post('/bolsa/form_ordens', 'BolsaController@ordensBroker');


Route::post('/bolsa/add_broker','BolsaController@addBroker');
Route::post('/bolsa/add_ordem', 'BolsaController@addOrdem');
Route::post('/bolsa/login', "LoginController@login");

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
