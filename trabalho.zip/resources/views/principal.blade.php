<!doctype html>

<html>
<head>
    <link rel="stylesheet" type="text/css" href="/css/app.css">
    <title>Bolsa de valores</title>
    <style>
        #container {
            margin: 50px;
            width: 400px;
            padding: 1em;
            border: 1px solid #CCC;
            border-radius: 1em;
            margin-top: 50px;
        }

        form div + div {
            margin-top: 1em;
        }


        button {
            /* Esta margem extra representa aproximadamente o mesmo espaço que o espaço entre as labels e os seus campos de texto*/
            adding-left: 90px;
            margin-left: .5em;
        }

        #teste {
            /* margin: 150px;*/
            /*  width: 100px; */
            padding: 5em;
            border: 1px solid #CCC;
            border-radius: 1em;
            /* text-align: center; */
        }

        body {
            background:white;
        }

        a{
            color:white;
        }

    </style>

</head>
<body>


<nav class="navbar navbar-expand-lg navbar-white bg-dark">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
                <a class="nav-item nav-link" href="/bolsa/index">Emitir ordem</a>

            <a class="nav-item nav-link" href="/bolsa/ativos">Ativos</a>
            <a class="nav-item nav-link" href="/bolsa/form_add">Cadastrar Broker</a>
            <!--
            <a class="nav-item nav-link" href="/bolsa/form_ordens">Ordens efetivadas</a>
            -->

        </div>
    </div>
</nav>

<div class="container">
@yield('conteudo')
</div>

</body>

</html>