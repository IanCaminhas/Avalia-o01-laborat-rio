@extends('principal')

@section('conteudo')
    <h1>Ativos da bolsa de valores</h1>
    <table class="table table-striped col-lg-12">
        <thead>
        <tr>
            <th scope="col">Nome Pregão</th>
            <th scope="col">Código</th>
            <th scope="col">Atividade Principal</th>
        </tr>
        @foreach($ativos as $ativo)
        <tr>
            <td>{{$ativo->codigo}}</td>
            <td>{{$ativo->nome_pregao}}</td>
            <td>{{$ativo->atividade_principal}}</td>
        </tr>
            @endforeach
        </thead>
        <tbody>
        </tbody>
    </table>

@stop