@extends('principal')

@section('conteudo')


        @if(isset($response))
            {{$response}}
        @endif


    <form action="/bolsa/index">
        <div>
            <button class="btn btn-primary" type="submit">retornar</button>
        </div>
    </form>

@stop