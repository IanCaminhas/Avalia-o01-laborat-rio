@extends('principal')

@section('conteudo')

    <table class="table table-striped col-lg-12">
        <thead>
        <tr>
            <th scope="col">Broker</th>
            <th scope="col">Natureza</th>
            <th scope="col">Ativo</th>
            <th scope="col">Quantidade lotes</th>
        </thead>
        <tbody>

        </tr>
        @if(isset($ordens))
          @foreach($ordens as $o)
                <tr>
                    <td>{{$o->broker->nome}}</td>
                    <td>{{$o->natureza}}</td>
                    <td>{{$o->ativo->nome_pregao}}</td>
                    <td>{{$o->qtd_lotes}}</td>
                </tr>
            @endforeach
        @endif
        </tbody>
    </table>


    <form action="/bolsa/form_ordens" method="post" id="ordem_compra">
        <input type="hidden" name="_token" value="{{csrf_token()}}"/>

        <div class="form-group">
            <label>Nome Broker:</label>
            <input name="broker" class="form-control" />
        </div>

        <div class="form-group">
            <label>Senha:</label>
            <input name="senha" type="password" class="form-control" />
        </div>

        <div>
            <button class="btn btn-primary" type="submit">pesquisar</button>
        </div>
    </form>


    @stop
