@extends('principal')

@section('conteudo')

<div class="container">
    <!--
<table class="table table-striped col-lg-12">
    <thead>
    <tr>
        <th scope="col">Broker</th>
        <th scope="col">Natureza</th>
        <th scope="col">Lotes</th>
        <th scope="col">Valor</th>
        <th scope="col">Comprar</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>

-->

<form action="/bolsa/add_ordem" method="post" id="ordem_compra">
    <input type="hidden" name="_token" value="{{csrf_token()}}"/>

    <div class="form-group">
        <label>Numero de lotes:</label>
        <input name="lotes" class="form-control" />
    </div>

    <div>
        <label>Natureza da ordem:</label>
        <select name="natureza" class="form-control" />
            <option value="compra">compra</option>
            <option value="venda">venda</option>
        </select>
    </div>


    <div>
        <label>Ativo:</label>
        <select name="codigo_ativo" class="form-control" />
        @foreach($ativos as $a)
            <option value="{{$a->codigo}}">{{$a->nome_pregao}}</option>
            @endforeach
            </select>
    </div>

    <div class="form-group">
        <label>A sua identificação como broker: </label>
        <input name="broker" class="form-control" />
    </div>

    <div class="form-group">
        <label>Senha:</label>
        <input name="senha" class="form-control" type="password" />
    </div>

    <div>
    <button class="btn btn-primary" type="submit">emitir</button>
    </div>

</form>
</div>

    <div class="alert-danger">
        <ul>
            @foreach($errors->all() as $error)
                <li>{{$error}}</li>
            @endforeach
        </ul>
    </div>

<!--
<div class="alert-danger">

    @if(isset($response))
        <div class="alert alert-danger">
            {{$response}}
        </div>
    @endif
</div>
-->





@stop