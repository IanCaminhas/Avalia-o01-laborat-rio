@extends('principal')

@section('conteudo')


    <div class="alert-danger">

     @if(isset($response))
            <div class="alert alert-danger">
                {{$response}}
            </div>
                @endif
    </div>


    <form action="/bolsa/add_broker" method="post" id="ordem_compra">
        <input type="hidden" name="_token" value="{{csrf_token()}}"/>

        <div class="form-group">
            <label>Nome Broker:</label>
            <input name="nome" class="form-control" />
        </div>

        <div class="form-group">
            <label>Senha:</label>
            <input name="senha" type="password" class="form-control" />
        </div>

        <div>
            <button class="btn btn-primary" type="submit">cadastrar</button>
        </div>
    </form>

@stop